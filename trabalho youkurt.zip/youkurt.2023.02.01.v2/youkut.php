<?php

if(isset($_POST['acao']))
{

include_once("config.php");

  $nome_de_usuario = $_POST['nome_de_usuario'];

  $nome = $_POST['nome'];

  $email = $_POST['email'];

  $senha = $_POST['senha'];

  $nascimento = $_POST['nascimento'];

  $sexo = $_POST['sexo'];

  $telefone = $_POST['telefone'];

 //$usuario = $_POST['usuario'];

  $result = mysqli_query($conexao,"INSERT INTO cadastro(nome_de_usuario,nome,email,senha,nascimento,sexo,telefone)
  values('$nome_de_usuario','$nome','$email','$senha','$nascimento','$sexo','$telefone')");

//para nao ter contas duplicadas    

//$duplicate = mysqli_query($conn, "SELECT * FROM cliente where senha = '$senha' or email = '$email'");
   //if(mysqli_num_rows($duplicate) > 0){
       // echo "<script> alert('Nome de usuário ou Email já cadastrado'); </script>";
   // }
}


?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Youkut|Cadastre-se</title>
<link rel="stylesheet" href="youkut.css">
	
</head>
    
<body>
	

	
    <form action="youkut.php" class="espaco caixote1" method="post"> 
		<br>
		<div id="caixonete1">
		<div class="box">  <img src="logo1.jpg" class="box1 box2">  </div>
		</div>
		<div class="caixote2">
				<br>
			<p>     </p>
				<br>
        <h1 class="fonte2"> Cadastre-se grátis agora!</h1>
       
        <div class="field fonte1">
            <label for="nome">Nome de Usuário:</label>
            <input type="text" id="nome_de_usuario" name="nome_de_usuario" placeholder="Digite seu nome de Usuário" required>
        </div>
	
        
	<div class="field fonte1">
		 <label for="sexo"> Sexo:</label> <br>
<select name="sexo">
<option value="Feminino">Feminino</option>
<option value="Masculino">Masculino</option>
<option value="Outro">Outro</option>
<option value="Prefiro não informar">Prefiro não informar</option>
</select>
		
	</div>
	
		
		<div class="field fonte1">
            <label for="nome">Nome Completo:</label>
            <input type="text" id="nome" name="nome" placeholder="Digite seu Nome" required>
        </div>
        
        <div class="field fonte1">
            <label for="telefone">Telefone:</label>
            <input type="text" id="telefone" name="telefone" placeholder="Digite seu Telefone">
        </div>

		<div class="field fonte1">
            <label for="nascimento">Data da nascimento:</label>
            <input type="date" id="nascimento" name="nascimento" placeholder="Sua data de aniversário">
        </div>
		
		
        <div class="field fonte1">
            <label for="email">E-Mail:</label>
            <input type="email" id="email" name="email" placeholder="Digite seu E-Mail*" required>
        </div>        
       
        <div class="field fonte1">
            <label for="mensagem">Crie uma Senha:</label>
            <input type="password" name="senha" id="senha" placeholder="Digite sua Senha" required>
        </div>
  <input class ="button"  type ="submit" name="acao" value="ENVIAR">
	  
	
	
		
	
	</form>
	

</body>
</html>