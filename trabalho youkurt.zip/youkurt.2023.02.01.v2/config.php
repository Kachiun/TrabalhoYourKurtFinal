<?php
//host (com sua porta), nome de usuario no banco, senha, schema
$conexao = new mysqli("localhost:3306","root","","Yourkut");

if($conexao->connect_errno){
    echo "tem alguma coisa errada";
}else {
    echo "Cadastrado com sucesso";
}

?>